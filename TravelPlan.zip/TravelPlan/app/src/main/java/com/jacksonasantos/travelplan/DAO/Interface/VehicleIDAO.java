package com.jacksonasantos.travelplan.DAO.Interface;

import com.jacksonasantos.travelplan.DAO.Vehicle;

import java.util.List;

public interface VehicleIDAO {
    public Vehicle fetchUserById(int userId);
    public List<Vehicle> fetchAllUsers();
    // add Vehicle
    public boolean addVehicle(Vehicle vehicle);
    // add Vehicle in bulk
    public boolean addVehicles(List<Vehicle> vehicle);
    public boolean deleteAllVehicles();
    public boolean deleteVehicle(int id);
}