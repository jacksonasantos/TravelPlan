package com.jacksonasantos.travelplan.DAO.Interface;

import com.jacksonasantos.travelplan.DAO.User;

import java.util.List;

public interface UserIDAO {
    public User fetchUserById(int userId);
    public List<User> fetchAllUsers();
    // add user
    public boolean addUser(User user);
    // add users in bulk
    public boolean addUsers(List<User> users);
    public boolean deleteAllUsers();
    public boolean deleteUser(int id);
}