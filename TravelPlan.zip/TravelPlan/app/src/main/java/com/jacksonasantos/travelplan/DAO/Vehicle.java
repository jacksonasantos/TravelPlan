package com.jacksonasantos.travelplan.DAO;

public class Vehicle {
    private static final long serialVersionUID = 163383301108440384L;
    public int id;
    public String oid;
    public String name;
    public String license_plate;
    public int full_capacity;
    public double avg_consumption;
}
