package com.jacksonasantos.travelplan.DAO;

import java.sql.Date;

public class User {
    public int id;
    public String username;
    public String email;
    public Date createdDate;
}