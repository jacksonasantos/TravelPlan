package com.jacksonasantos.travelplan.ui.vehicle;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.jacksonasantos.travelplan.DAO.Database;
import com.jacksonasantos.travelplan.DAO.Vehicle;
import com.jacksonasantos.travelplan.DAO.VehicleDAO;
import com.jacksonasantos.travelplan.R;

public class VehicleActivity extends Activity {

    private EditText etOIDVehicle;
    private EditText etNameVehicle;
    private EditText etLicencePlateVehicle;
    private EditText etFullCapacity;
    private EditText etAVGConsumption;
    private Vehicle vehicle;
    private boolean isSave = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);
        setTitle("Identificação do Veículo");

        etOIDVehicle = findViewById(R.id.etOIDVehicle);
        etNameVehicle = findViewById(R.id.etNameVehicle);
        etLicencePlateVehicle = findViewById(R.id.etLicencePlateVehicle);
        etFullCapacity = findViewById(R.id.etFullCapacity);
        etAVGConsumption = findViewById(R.id.etAVGConsumption);

        Intent intent = getIntent();
        vehicle = (Vehicle) intent.getSerializableExtra("vehicle");
        if (vehicle != null) {
            etOIDVehicle.setText(vehicle.oid);
            etNameVehicle.setText(vehicle.name);
            etLicencePlateVehicle.setText(vehicle.license_plate);
            etFullCapacity.setText(vehicle.full_capacity);
            etAVGConsumption.setText((int) vehicle.avg_consumption);
        }
    }

    public void save_vehicle(View v){
        Toast.makeText(this, "entrou", Toast.LENGTH_SHORT).show();
        Database db = new Database(this);
        Toast.makeText(this, "passou Database", Toast.LENGTH_SHORT).show();
        db.open();
        Toast.makeText(this, "passou Open Database", Toast.LENGTH_SHORT).show();

/*        if (vehicle != null){
            Toast.makeText(this, "Exemplo UPDATE", Toast.LENGTH_SHORT).show();
           isSave = Database.mVehicleDao.updateVehicle(vehicle);
        } else {
            Toast.makeText(this, "Exemplo ADD", Toast.LENGTH_SHORT).show();
            vehicle.oid = etNameVehicle.getText().toString();
            vehicle.name = etOIDVehicle.getText().toString();
            vehicle.license_plate = etLicencePlateVehicle.getText().toString();
            vehicle.full_capacity = Integer.parseInt(etFullCapacity.getText().toString());
            vehicle.avg_consumption = Double.parseDouble(etAVGConsumption.getText().toString());

            isSave = Database.mVehicleDao.addVehicle(vehicle);
            Toast.makeText(this, "Exemplo ADD + "+isSave, Toast.LENGTH_SHORT).show();
        }
*/
        db.close();
        setResult(isSave ? 1 : 0);
        finish();
    }
}

/*      //em qualquer parte do seu aplicativo, você pode pegar um usuário por seu id desta forma:
        Vehicle vehicle = Database.mVehicleDao.fetchVehicleById(VehicleId);
 */